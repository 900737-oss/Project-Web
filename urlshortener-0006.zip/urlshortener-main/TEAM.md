# TEAM.md 
---

## Members

| Personal name | UNIZAR email (`…@unizar.es`) | git `user.name` | GitHub id | Owned features | Integrator |
| --- | --- | --- | --- | --- | --- |
| Tomas Martinez, Daniel | 845107@unizar.es | DTomass | @DTomass | docs/features/0007-qr-code.md, docs/features/0005-csv-upload.md | no |
| Lacambra Simón, Daniel | 798541@unizar.es | Danii-LS | @Danii-LS | docs/features/0008-async_click_ingestion.md | no |
| Andrés Soria, Jorge Javier | 900737@unizar.es | 900737-oss | @900737-oss | docs/features/0006-redirect_cache_cross_replica.md | **yes** |
| Foz Bernad, Sergio | 901315@unizar.es | Sergio Foz Bernad | @sergiofoz | docs/features/0004-link_preview_open_graph.md | no |

---

